// Variables globales
const treeContainer = document.getElementById("tree-container");
const treeSvg = document.getElementById("tree");
let treeData = [];
let steps = [];
let currentStepIndex = 0;
let isAlphaBeta = false; // Indica si se ejecuta el algoritmo de poda
let selectedNode = null;
let isAdding = false; // Control de estado para evitar múltiples adiciones
let isMinimax = false;  // Inicialmente no estamos en Minimax

circle.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    selectedNode = node;
    showNodeMenu(node, event.clientX, event.clientY);
});
const levels = document.querySelectorAll('.level');
levels.forEach((level, index) => {
    level.style.marginBottom = `${50 + index * 10}px`; // Aumenta el espacio con la profundidad
});

// Generar árbol inicial
function generateTree() {
    const levels = parseInt(document.getElementById("levels").value);
    if (isNaN(levels) || levels < 1) {
        alert("Por favor, introduce un número mayor o igual a 1.");
        return;
    }

    treeData = []; // Reiniciar árbol
    steps = []; // Reiniciar pasos
    currentStepIndex = 0;
    treeSvg.innerHTML = ""; // Limpiar SVG

    // Crear nodo raíz
    const rootNode = {
        id: "0",
        level: 0,
        type: "max",
        value: null,
        children: [],
        parent: null,
    };
    treeData.push(rootNode);

    // Generar nodos hijos
    generateNodes(rootNode, levels - 1);

    // Dibujar árbol
    drawTree(treeData);
    alert("Árbol generado con éxito. Asigna valores a las hojas para continuar.");
}


// Generar nodos hijos recursivamente
function generateNodes(node, remainingLevels) {
    if (remainingLevels <= 0) return;

    const childType = node.type === "max" ? "min" : "max";

    for (let i = 0; i < 2; i++) {
        const childNode = {
            id: `${node.id}-${i}`,
            level: node.level + 1,
            type: childType,
            value: null,
            children: [],
            parent: node,
        };
        node.children.push(childNode);
        generateNodes(childNode, remainingLevels - 1);
    }
}

function generateExample() {
    const levels = 4;
    treeData = []; // Reiniciar árbol
    steps = []; // Reiniciar pasos
    currentStepIndex = 0;
    treeSvg.innerHTML = ""; // Limpiar SVG

    // Crear nodo raíz
    const rootNode = {
        id: "0",
        level: 0,
        type: "max",
        value: null,
        children: [],
        parent: null,
    };
    treeData.push(rootNode);

    // Generar nodos hijos con valores predeterminados
    generateNodes(rootNode, levels - 1);
    const leafValues = [12, -2, 45, 47, 12, 15, -7, 8];
    assignLeafValues(treeData[0], leafValues);

    // Dibujar árbol sin resolver
    drawTree(treeData);
    alert("Ejemplo generado. El árbol no está resuelto.");
}

// Asignar valores a las hojas en orden
function assignLeafValues(node, values) {
    if (node.children.length === 0) {
        node.value = values.shift(); // Asignar valores solo a las hojas
        return;
    }
    node.children.forEach((child) => assignLeafValues(child, values));
}
// Dibujar el árbol
function drawTree(nodes) {
    // Limpiar el SVG antes de dibujar el nuevo árbol
    while (treeSvg.firstChild) {
        treeSvg.removeChild(treeSvg.firstChild);
    }

    const width = treeContainer.offsetWidth; // Ancho dinámico del contenedor
    const maxLevel = getMaxLevel(nodes);
    const levelHeight = 120; // Altura fija entre niveles
    const nodeRadius = 20;

    const svgHeight = (maxLevel + 1) * levelHeight + nodeRadius * 2;
    treeSvg.setAttribute("width", width);
    treeSvg.setAttribute("height", svgHeight);

    positionNodes(nodes[0], width / 2, nodeRadius * 2, width / (Math.pow(2, maxLevel) + 1));
}

function positionNodes(node, x, y, spacing) {
    drawNode(node, x, y, node.parent?.x, node.parent?.y);
    node.x = x;
    node.y = y;

    const childY = y + 120; // Altura fija entre niveles
    const totalChildren = node.children.length;

    node.children.forEach((child, index) => {
        const childX = x + (index - (totalChildren - 1) / 2) * spacing;
        const newSpacing = spacing / 2; // Reducir espaciado para niveles inferiores
        positionNodes(child, childX, childY, newSpacing);
    });
}


function drawNode(node, x, y, parentX = null, parentY = null) {
   const nodeRadius = 20; // Radio del nodo
    if (parentX !== null && parentY !== null) {
        const angle = Math.atan2(y - parentY, x - parentX);
        const lineStartX = parentX + nodeRadius * Math.cos(angle);
        const lineStartY = parentY + nodeRadius * Math.sin(angle);
        const lineEndX = x - nodeRadius * Math.cos(angle);
        const lineEndY = y - nodeRadius * Math.sin(angle);

        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", lineStartX);
        line.setAttribute("y1", lineStartY);
        line.setAttribute("x2", lineEndX);
        line.setAttribute("y2", lineEndY);
        line.setAttribute("stroke", "#000");
        treeSvg.appendChild(line);
    }

    // Dibujar círculo del nodo
      const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute("cx", x);
    circle.setAttribute("cy", y);
    circle.setAttribute("r", nodeRadius);
    circle.setAttribute("fill", node.type === "max" ? "#ffcccb" : "#add8e6");
    circle.setAttribute("stroke", node.isCurrent ? "red" : "#000");
    circle.setAttribute("stroke-width", node.isCurrent ? 4 : 1);

    // Añadir evento para mostrar menú
    circle.addEventListener("contextmenu", (event) => {
        event.preventDefault(); // Evita el menú predeterminado del navegador
        showNodeMenu(node, event.clientX, event.clientY);
    });

    treeSvg.appendChild(circle);

    // Dibujar texto
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
    text.setAttribute("x", x);
    text.setAttribute("y", y + 5);
    text.setAttribute("text-anchor", "middle");
    text.setAttribute("font-size", "12px");
    text.textContent = node.value !== null ? node.value : node.type.toUpperCase();
    treeSvg.appendChild(text);

    // Dibujar valores de alfa y beta
    if (node.alpha !== undefined && node.beta !== undefined) {
        const alphaText = document.createElementNS("http://www.w3.org/2000/svg", "text");
        alphaText.setAttribute("x", x - 25);
        alphaText.setAttribute("y", y - 30);
        alphaText.setAttribute("font-size", "10px");
        alphaText.setAttribute("fill", "red");
        alphaText.textContent = `α: ${node.alpha}`;

        const betaText = document.createElementNS("http://www.w3.org/2000/svg", "text");
        betaText.setAttribute("x", x + 25);
        betaText.setAttribute("y", y - 30);
        betaText.setAttribute("font-size", "10px");
        betaText.setAttribute("fill", "blue");
        betaText.textContent = `β: ${node.beta}`;

        treeSvg.appendChild(alphaText);
        treeSvg.appendChild(betaText);
    }
}

function redrawTree() {
    // Limpiar el contenedor SVG
    treeSvg.innerHTML = "";

    // Redibujar el árbol completo basado en la estructura actual de `treeData`
    drawTree(treeData);
}


// Obtener el nivel máximo
function getMaxLevel(nodes) {
    let maxLevel = 0;
    function traverse(node) {
        maxLevel = Math.max(maxLevel, node.level);
        node.children.forEach(traverse);
    }
    traverse(nodes[0]);
    return maxLevel;
}
// Función para limpiar los valores alpha y beta de todos los nodos
function clearAlphaBetaValues(node) {
    node.alpha = undefined;
    node.beta = undefined;
    if (node.children.length > 0) {
        node.children.forEach(clearAlphaBetaValues);
    }
}

// Función para limpiar los valores de todos los nodos excepto los nodos hoja
function resetTreeValues(node) {
    if (node.children.length > 0) {
        // Limpiar valores y estados visuales del nodo actual
        node.value = null;
        node.alpha = -Infinity;
        node.beta = Infinity;
        node.isPruned = false;
        delete node.highlight;

        node.children.forEach(resetTreeValues);
    }
}

function startMinMax() {
    isMinimax = true;  // Establece que estamos en Minimax
    console.log("Botón Minimax presionado");
    if (!validateTree()) return;

    steps = []; // Reiniciar pasos
    resetTreeValues(treeData[0]); // Limpiar valores del árbol excepto los nodos hoja
    clearAlphaBetaValues(treeData[0]); // Eliminar valores alpha y beta
    currentStepIndex = 0; // Reiniciar índice de pasos

    // Eliminar nodos resaltados y otros valores visuales antes de comenzar
    treeData.forEach((node) => {
        node.isCurrent = false;  // Eliminar cualquier resaltado
        delete node.highlight;  // Eliminar cualquier resaltado visual
        delete node.alpha;      // Eliminar valores alpha y beta
        delete node.beta;
    });

    // Ejecutar el algoritmo de Minimax
    minimax(treeData[0], true);
    
    // Solo se debe guardar un paso final en Minimax
    steps.push({ node: treeData[0], value: treeData[0].value });

    // Resaltar el nodo final
    treeData[0].isCurrent = true;

    // Mostrar el árbol resuelto
    redrawTree();

    setupStepButtons();
    alert("Minimax ejecutado. Presiona 'Ver Resultado' para visualizar el árbol resuelto.");
}

function startAlphaBeta() {
    isMinimax = false;  // Indicamos que estamos usando Alpha-Beta
    console.log("Botón Alpha-Beta presionado");
    if (!validateTree()) return;

    steps = []; // Reiniciar pasos
    resetTreeValues(treeData[0]); // Limpiar valores del árbol excepto los nodos hoja
    clearAlphaBetaValues(treeData[0]); // Eliminar valores alpha y beta
    currentStepIndex = 0; // Reiniciar índice de pasos

    // Establecer alpha y beta infinitos para todos los nodos
    treeData.forEach((node) => {
        node.alpha = -Infinity; // Inicializamos alpha en -∞
        node.beta = Infinity;   // Inicializamos beta en ∞
    });

    // Ejecutar el algoritmo de Alpha-Beta
    alphabeta(treeData[0], -Infinity, Infinity, true);

    // Solo se debe guardar un paso final en Alpha-Beta
    steps.push({ node: treeData[0], value: treeData[0].value });

    // Resaltar el nodo final
    treeData[0].isCurrent = true;

    // Mostrar el árbol resuelto
    redrawTree();

    setupStepButtons();
    alert("Alpha-Beta ejecutado. Presiona 'Ver Resultado' para visualizar el árbol resuelto.");
}

function minimax(node, isMaximizing) {
    console.log(`Evaluando nodo ${node.id} (${isMaximizing ? "MAX" : "MIN"})`);
    if (node.children.length === 0) {
        console.log(`Nodo hoja ${node.id} con valor ${node.value}`);
        steps.push({ node, value: node.value });
        return node.value;
    }

    const values = node.children.map((child) =>
        minimax(child, !isMaximizing)
    );
    node.value = isMaximizing ? Math.max(...values) : Math.min(...values);
    console.log(`Nodo ${node.id} actualizado a valor ${node.value}`);
    steps.push({ node, value: node.value });
    return node.value;
}

function alphabeta(node, alpha, beta, isMaximizing) {
    console.log(`Evaluando nodo ${node.id} (${isMaximizing ? "MAX" : "MIN"}), Alpha: ${alpha}, Beta: ${beta}`);
    
    // Si es un nodo hoja, devuelve su valor
    if (node.children.length === 0) {
        console.log(`Nodo hoja ${node.id} con valor ${node.value}`);
        steps.push({ node, value: node.value });
        return node.value;
    }

    let value;
    if (isMaximizing) {
        value = -Infinity;
        // Iterar por los hijos para encontrar el valor máximo
        for (const child of node.children) {
            value = Math.max(value, alphabeta(child, alpha, beta, false));
            node.value = value;
            console.log(`Nodo ${node.id} actualizado a valor ${value}`);
            steps.push({ node, value: node.value });
            if (value >= beta) {
                console.log(`Poda en nodo ${node.id} (Beta podado)`);
                break;  // Poda Beta
            }
            alpha = Math.max(alpha, value);
            node.alpha = alpha;  // Actualizar alpha en el nodo
        }
    } else {
        value = Infinity;
        // Iterar por los hijos para encontrar el valor mínimo
        for (const child of node.children) {
            value = Math.min(value, alphabeta(child, alpha, beta, true));
            node.value = value;
            console.log(`Nodo ${node.id} actualizado a valor ${value}`);
            steps.push({ node, value: node.value });
            if (value <= alpha) {
                console.log(`Poda en nodo ${node.id} (Alpha podado)`);
                break;  // Poda Alpha
            }
            beta = Math.min(beta, value);
            node.beta = beta;  // Actualizar beta en el nodo
        }
    }

    return value;
}


function validateTree() {
    const leaves = [];
    function collectLeaves(node) {
        if (node.children.length === 0) leaves.push(node);
        else node.children.forEach(collectLeaves);
    }
    collectLeaves(treeData[0]);

    const uninitialized = leaves.filter((leaf) => leaf.value === null);
    if (uninitialized.length > 0) {
        alert("Todas las hojas deben tener un valor asignado.");
        console.log("Nodos sin valores:", uninitialized);
        return false;
    }
    return true;
}


// Configurar botones de pasos
function setupStepButtons() {
   currentStepIndex = 0; // Reiniciar el índice de pasos
    applyStep(steps[0]); // Aplicar y resaltar el primer paso
    document.getElementById("prevStep").hidden = false;
    document.getElementById("nextStep").hidden = false;
    document.getElementById("viewResult").hidden = false;
}

function nextStep() {
    if (currentStepIndex < steps.length - 2) {
        currentStepIndex++;
        applyStep(steps[currentStepIndex]); // Restaurar los valores definidos en el paso actual
    } else {
        alert("No hay más pasos siguientes.");
    }
}


function previousStep() {
    if (currentStepIndex > 0) {
        currentStepIndex--;

        // Recorremos los pasos y restablecemos los valores según el estado del paso actual
        steps.forEach((step, index) => {
            step.node.isCurrent = index === currentStepIndex;

            if (index >= currentStepIndex) {
                if (step.node.children && step.node.children.length > 0) {
                    // Guardar los valores antes de modificarlos para poder restaurarlos en `nextStep`
                    if (!step.savedState) {
                        step.savedState = {
                            value: step.node.value,
                            alpha: step.node.alpha,
                            beta: step.node.beta,
                            isPruned: step.node.isPruned,
                            highlight: step.node.highlight
                        };
                    }

                    // Limpiar valores y estilos visuales, pero solo eliminar alpha y beta si no estamos en Minimax
                    step.node.value = null;
                    step.node.alpha = -Infinity;
                    step.node.beta = Infinity;
                    step.node.isPruned = false;
                    delete step.node.highlight;

                    // Si el algoritmo es Minimax, no restauramos alpha y beta
                    if (isMinimax) { // Necesitas definir esta variable cuando se esté ejecutando Minimax
                        step.node.alpha = undefined; 
                        step.node.beta = undefined;
                    }
                }
            } else {
                // Restaurar valores si hay un estado guardado, pero solo restaurar alpha y beta si estamos en Alfa-Beta
                if (step.savedState) {
                    step.node.value = step.savedState.value;

                    // Restaurar alpha y beta solo si estamos en Alfa-Beta
                    if (!isMinimax) { 
                        step.node.alpha = step.savedState.alpha;
                        step.node.beta = step.savedState.beta;
                    }
                    step.node.isPruned = step.savedState.isPruned;
                    step.node.highlight = step.savedState.highlight;
                }
            }
        });

        // Limpiar nodos pruned
        treeData.forEach((node) => {
            if (node.isPruned) {
                node.isPruned = false;
                delete node.highlight;
            }
        });

        redrawTree();
    } else {
        alert("No hay más pasos anteriores.");
    }
}
	


function applyStep(step) {
    // Reiniciar el estado actual de todos los nodos
    treeData.forEach((node) => (node.isCurrent = false));
    step.node.isCurrent = true; // Marcar el nodo actual como "activo"

    // Restaurar los valores del nodo actual desde savedState si existe
    if (step.savedState) {
        step.node.value = step.savedState.value;
        step.node.alpha = step.savedState.alpha;
        step.node.beta = step.savedState.beta;
    } else {
        // Restaurar los valores definidos en el paso actual
        if ("value" in step) step.node.value = step.value;
        if ("alpha" in step) step.node.alpha = step.alpha;
        if ("beta" in step) step.node.beta = step.beta;
    }

    // Restaurar valores de todos los nodos hijos relacionados con este paso
    if (step.node.children && step.node.children.length > 0) {
        step.node.children.forEach((child) => {
            let childStep = steps.find((s) => s.node === child);
            if (childStep) {
                if (childStep.savedState) {
                    child.value = childStep.savedState.value;
                    child.alpha = childStep.savedState.alpha;
                    child.beta = childStep.savedState.beta;
                } else {
                    if ("value" in childStep) child.value = childStep.value;
                    if ("alpha" in childStep) child.alpha = childStep.alpha;
                    if ("beta" in childStep) child.beta = childStep.beta;
                }
            }
        });
    }

    redrawTree(); // Actualizar el árbol en la interfaz
}

function showResult() {
    // Asegurarse de que todos los valores estén restaurados
    steps.forEach((step) => {
        // Si estamos en Minimax, solo debemos mostrar `value`. En Alfa-Beta mostramos `alpha` y `beta`
        if (!isMinimax) { // Poda Alfa-Beta
            step.node.alpha = step.node.alpha !== undefined ? step.node.alpha : null;
            step.node.beta = step.node.beta !== undefined ? step.node.beta : null;
        }
    });

    // Resaltar la raíz
    const root = treeData[0];
    root.isCurrent = true;

    // Mostrar el resultado final en la raíz
    alert(`El valor calculado de la raíz es: ${root.value}`);

    // Limpiar cualquier otro resaltado de nodos
    treeData.forEach((node) => {
        if (node !== root) {
            node.isCurrent = false;
        }
    });

    // Redibujar el árbol para reflejar los valores resueltos
    redrawTree();
}

function resetTree() {
    // Vaciar todos los datos del árbol
    treeData = [];
    steps = [];
    currentStepIndex = 0;
    treeSvg.innerHTML = ""; // Limpiar el contenedor SVG

    // Crear nodo raíz vacío
    const rootNode = {
        id: "0",
        level: 0,
        type: "max", // Tipo predeterminado
        value: null,
        alpha: -Infinity,
        beta: Infinity,
        children: [],
        parent: null,
    };

    treeData.push(rootNode);

    // Dibujar solo el nodo raíz vacío
    drawTree(treeData);
    alert("El árbol se ha reiniciado completamente.");
}
function addChild(node) {
    if (isAdding) return; // Evitar llamadas simultáneas
    isAdding = true;

    if (!node) {
        console.error("No se ha proporcionado un nodo para agregar.");
        isAdding = false; // Restablecer estado
        return;
    }

    console.log("Agregando hijo al nodo:", node.id);

    const childType = node.type === "max" ? "min" : "max";
    const currentChildCount = node.children.length;

    // Crear el nuevo nodo hijo
    const newNode = {
        id: `${node.id}-${currentChildCount}`,
        level: node.level + 1,
        type: childType,
        value: null,
        children: [],
        parent: node,
    };

    // Agregar el nodo al arreglo de hijos
    node.children.push(newNode);

    console.log(`Nodo agregado: ${newNode.id}`);

    // Redibujar el árbol tras agregar el nodo
    redrawTree();
    isAdding = false; // Restablecer estado
}


function deleteNode(node) {
    if (!node.parent) {
        alert("No puedes eliminar la raíz.");
        return;
    }

    // Confirmación si el nodo tiene hijos
    if (node.children.length > 0) {
        const confirmDelete = confirm(
            `El nodo ${node.id} tiene ${node.children.length} hijos. ¿Estás seguro de que deseas eliminarlo junto con todos sus hijos?`
        );
        if (!confirmDelete) return;
    }

    // Eliminar el nodo del padre
    const parent = node.parent;
    parent.children = parent.children.filter((child) => child.id !== node.id);

    console.log(`Nodo eliminado: ${node.id}`);
    redrawTree();
}
// Cambiar el valor de un nodo
function setNodeValue(node) {
    // Verificar si el nodo es una hoja
    if (node.children && node.children.some(child => child !== null)) {
        alert("Solo se pueden asignar valores a los nodos hijos (hojas).");
        return;
    }

     const newValue = prompt("Ingresa un valor numérico:");

    // Validar que la entrada sea un número
    if (newValue !== null && !isNaN(newValue) && newValue.trim() !== "") {
        node.value = Number(newValue);
        alert(`Valor cambiado a: ${node.value}`);
    } else {
        alert("Entrada inválida. Solo se permiten valores numéricos.");
    }

    node.value = newValue;
    console.log(`Valor del nodo ${node.id} cambiado a ${node.value}`);

    // Actualizar la visualización del nodo
    drawTree(treeData);
}

function showNodeMenu(node, x, y) {
    // Eliminar menú previo si existe
    const existingMenu = document.getElementById("node-menu");
    if (existingMenu) existingMenu.remove();

    // Crear y mostrar el nuevo menú
    const menu = document.createElement("div");
    menu.id = "node-menu";
    menu.style.position = "absolute";
    menu.style.left = `${x}px`;
    menu.style.top = `${y}px`;
    menu.style.background = "#fff";
    menu.style.border = "1px solid #ccc";
    menu.style.padding = "10px";
    menu.style.zIndex = "1000";

    // Crear botones del menú
    let menuContent = `
        <button onclick="addChild(selectedNode)">Añadir Hijo</button>
        <button onclick="deleteNode(selectedNode)">Eliminar Nodo</button>
    `;

    // Verificar si el nodo es un hijo antes de agregar la opción de cambiar valor
    if (isChildNode(node)) {
        menuContent += `<button onclick="setNodeValue(selectedNode)">Cambiar Valor</button>`;
    }

    menu.innerHTML = menuContent;

    document.body.appendChild(menu);

    selectedNode = node;

    // Eliminar menú al hacer clic fuera
    document.addEventListener(
        "click",
        () => {
            const existingMenu = document.getElementById("node-menu");
            if (existingMenu) existingMenu.remove();
        },
        { once: true }
    );
}

// Función para determinar si el nodo es un hijo
function isChildNode(node) {
    return node.parent !== null && node.parent !== undefined;
}


function viewResult() {
    // Limpiar todos los resaltados
    treeData.forEach((node) => (node.isCurrent = false));

    // Resaltar solo la raíz
    const root = treeData[0];
    root.isCurrent = true;

    redrawTree();
    alert(`El resultado final es: ${root.value}`);
}